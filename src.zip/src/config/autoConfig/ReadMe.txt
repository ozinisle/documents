Do Not Modify the contents inside this folder. Files in this folder are created and updates programatically and will be used between subsequent program runs. 

Modification requires extreme architectural knowledge of this application and any inadverent/miscalculated change might result in absurd operations and program executions